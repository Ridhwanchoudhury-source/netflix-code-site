from flask import Flask, render_template
import imaplib
import email
import re
import os

app = Flask(__name__)

EMAIL_ADDRESS = os.getenv("EMAIL_ADDRESS")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")

def get_latest_netflix_code():
    try:
        mail = imaplib.IMAP4_SSL("imap.gmail.com")
        mail.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        mail.select("inbox")

        status, messages = mail.search(None, '(FROM "info@account.netflix.com")')

        email_ids = messages[0].split()
        if not email_ids:
            return "No Netflix emails found"

        latest_email_id = email_ids[-1]

        status, msg_data = mail.fetch(latest_email_id, "(RFC822)")

        raw_email = msg_data[0][1]
        msg = email.message_from_bytes(raw_email)

        body = ""

        if msg.is_multipart():
            for part in msg.walk():
                content_type = part.get_content_type()
                if content_type == "text/plain":
                    body += part.get_payload(decode=True).decode(errors="ignore")
        else:
            body = msg.get_payload(decode=True).decode(errors="ignore")

        match = re.search(r'\\b\\d{4}\\b', body)

        if match:
            return match.group(0)

        return "No code found"

    except Exception as e:
        return f"Error: {str(e)}"

@app.route("/")
def home():
    code = get_latest_netflix_code()
    return render_template("index.html", code=code)

if __name__ == "__main__":
    app.run(debug=True)
