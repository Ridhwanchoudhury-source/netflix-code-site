# Netflix Verification Code Viewer

## What this does
This private Flask website:
1. Connects to your Gmail inbox
2. Looks for Netflix verification emails
3. Extracts the latest 4-digit code
4. Displays it on a webpage

## Setup

### 1. Install requirements
```bash
pip install -r requirements.txt
```

### 2. Create a Gmail App Password
Google Account → Security → 2-Step Verification → App Passwords

### 3. Set environment variables

Mac/Linux:
```bash
export EMAIL_ADDRESS="yourgmail@gmail.com"
export EMAIL_PASSWORD="yourapppassword"
```

Windows CMD:
```cmd
set EMAIL_ADDRESS=yourgmail@gmail.com
set EMAIL_PASSWORD=yourapppassword
```

### 4. Run the app
```bash
python app.py
```

Open:
http://127.0.0.1:5000

## Optional Hosting
- Railway
- Render
- VPS
